package com.employee.app.start.EmployeeManagement;

import org.springframework.web.bind.annotation.ResponseStatus;

public class UserNotFoundException extends Throwable {
	 public UserNotFoundException(String message) {
	        super(message);
	    }
}
