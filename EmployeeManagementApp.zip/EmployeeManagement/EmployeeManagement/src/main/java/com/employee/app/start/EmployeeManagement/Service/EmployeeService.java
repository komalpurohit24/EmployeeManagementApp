package com.employee.app.start.EmployeeManagement.Service;

import java.util.UUID;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employee.app.start.EmployeeManagement.Model.Employee;
import com.employee.app.start.EmployeeManagement.Repository.EmployeeRepository;

@Service
@Transactional
public class EmployeeService {
	
@Autowired	
private final EmployeeRepository employeeRepository;

public EmployeeService(EmployeeRepository employeeRepository) {
	//super();
	this.employeeRepository = employeeRepository;
}

public Employee addEmployee(Employee employee) {
	
	return employeeRepository.save(employee);
}

public long findEmployeeByCity(String city) {
	return employeeRepository.countEmployeeByCity(city);
}

public Employee findEmployeeByDepartment(String departement) {
	return employeeRepository.countEmployeeByDepartement(departement);
}

public Employee updateEmployee(Employee employee) {
	return employeeRepository.save(employee);
}

public Employee findById(long id) {
	return employeeRepository.getById(id);
}



}
