package com.employee.app.start.EmployeeManagement.Model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


@Entity
public class Employee implements Serializable {
	 @Id
	 @GeneratedValue(strategy = GenerationType.AUTO)
	 @Column(nullable = false, updatable = false)
	 private Long employee_id;
	 private String first_name;
	 private String last_name;
	 private String city;
	 private int age;
	 private double salary;
	 private String departement;
	
	 public Employee() {
		super();
	}

	public Employee(String first_name, String last_name, String city, int age, double salary, String departement) {
		super();
		this.first_name = first_name;
		this.last_name = last_name;
		this.city = city;
		this.age = age;
		this.salary = salary;
		this.departement = departement;
	}

	public Long getEmployee_id() {
		return employee_id;
	}

	public void setEmployee_id(Long employee_id) {
		this.employee_id = employee_id;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getDepartement() {
		return departement;
	}

	public void setDepartement(String departement) {
		this.departement = departement;
	}

	@Override
	public String toString() {
		return "Employee [employee_id=" + employee_id + ", first_name=" + first_name + ", last_name=" + last_name
				+ ", city=" + city + ", age=" + age + ", salary=" + salary + ", departement=" + departement + "]";
	}

	 
}
