package com.employee.app.start.EmployeeManagement.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.employee.app.start.EmployeeManagement.Model.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

	@Query("Select top 1 count(*) from Employee Group By city Order by 1 desc")
	long countEmployeeByCity(String city);
	
	@Query("Select Departement,count(employee_id) from Employee Group By departement")
	Employee countEmployeeByDepartement(String departement);
}
